# measuring-size-and-distance-of-object-using-opencv-python
This repository helps you to build a project that performs measuring the size and distance of object using opencv and numpy python libraries
